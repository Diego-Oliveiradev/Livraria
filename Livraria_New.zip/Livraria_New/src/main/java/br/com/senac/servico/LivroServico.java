package br.com.senac.servico;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import br.com.senac.dominio.Livro;
import br.com.senac.repositorio.LivroRepositorio;
import br.com.senac.servico.exception.ObjectNotFoundException;



@Service
public class LivroServico {
	
	@Autowired
	private LivroRepositorio repoLivro;
	
	private Livro inserir (Livro livro) {
		livro.setId(null);
		return repoLivro.save(livro);
	}
	
	private void excluir(Integer id) {
		repoLivro.deleteById(id);
	}

	private Livro listar(Integer id) throws javassist.tools.rmi.ObjectNotFoundException {
		Optional<Livro> objLivro = repoLivro.findById(id);
		return objLivro.orElseThrow(() -> new ObjectNotFoundException
				("Curso nao encontrado! id:" + id + ", Tipo: " + Livro.class.getName())); 
	}
	
	private Livro alterar(Livro objLivro) throws javassist.tools.rmi.ObjectNotFoundException {
		Livro objLivroEncontrado = listar(objLivro.getId());
		objLivroEncontrado.setNome(objLivro.getNome());
		objLivroEncontrado.setPreco(objLivro.getPreco());
		objLivroEncontrado.setAutor(objLivro.getAutor());

		
		return repoLivro.save(objLivroEncontrado);
	}
	
	
	
}

