package br.com.senac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.senac.servico.FabricanteServico;

public class FabricanteController {

	@Autowired
	private FabricanteServico fabricanteServico;
	
	@GetMapping("/listarFabricante")
	public ModelAndView listaFabricantes() {
		ModelAndView mv = new ModelAndView("Fabricante/paginaFabricantes");
		mv.addObject("fabricantes", fabricanteServico.listaFabricantes());
		return mv;
	}
}
