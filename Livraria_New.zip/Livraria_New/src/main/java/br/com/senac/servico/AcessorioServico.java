package br.com.senac.servico;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senac.dominio.Acessorio;
import br.com.senac.repositorio.AcessorioRepositorio;

@Service
public class AcessorioServico {

	
	@Autowired
	private AcessorioRepositorio repoAcessorio;
	
	public Acessorio incluir(Acessorio acessorio) {
		acessorio.setId(null);
		return repoAcessorio.save(acessorio);
	}
	
	public List<Acessorio> listaAcessorio(){
		return repoAcessorio.findAll();
		
	}
}
