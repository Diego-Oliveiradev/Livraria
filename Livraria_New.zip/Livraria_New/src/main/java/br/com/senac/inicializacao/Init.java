package br.com.senac.inicializacao;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import br.com.senac.dominio.Livro;
import br.com.senac.repositorio.LivroRepositorio;
import br.com.senac.servico.CarroServico;
import br.com.senac.servico.ChaveServico;
import br.com.senac.servico.DocumentoServico;
import br.com.senac.servico.FabricanteServico;
import br.com.senac.dominio.Carro;
import br.com.senac.dominio.Chave;
import br.com.senac.dominio.Documento;
import br.com.senac.dominio.Fabricante;


@Component
public class Init implements ApplicationListener<ContextRefreshedEvent>{
	
	//@Autowired
	//LivroRepositorio livroRepositorio;
	
	@Autowired
	CarroServico carroServico;
	
	@Autowired
	ChaveServico chaveServico;
	
	@Autowired
	DocumentoServico documentoServico;
	
	@Autowired
	FabricanteServico fabricanteServico;
	

public void onApplicationEvent(ContextRefreshedEvent event){

	
	Fabricante fabricante1 = new Fabricante();
	fabricante1.setNome("GM");
	fabricanteServico.incluir(fabricante1);
	
	Documento documento1 = new Documento();
	documento1.setName("ABC123"); 
	documentoServico.incluir(documento1);
	
	
	Chave chave1 = new Chave();
	chave1.setNome("ASD124");
	chaveServico.incluir(chave1);
	
	Carro carro1 = new Carro();
	carro1.setNome("Palio 200");
    carro1.setChave(chave1);
    carro1.setDocumento(documento1);
    carro1.setFabricante(fabricante1);
    carroServico.inserir(carro1);
    
	Fabricante fabricante2 = new Fabricante();
	fabricante2.setNome("FIAT");
	fabricanteServico.incluir(fabricante2);   
	
	Documento documento2 = new Documento();
	documento2.setName("ABC456"); 
	documentoServico.incluir(documento2);	
	
	
	Chave chave2 = new Chave();
	chave2.setNome("FRR458");	
	chaveServico.incluir(chave2);
	
	Carro carro2 = new Carro();
	carro2.setNome("Golf");
	carro2.setChave(chave2);
	carro2.setDocumento(documento2);
	carro2.setFabricante(fabricante2);
	carroServico.inserir(carro2);    
	
	Fabricante fabricante3 = new Fabricante();
	fabricante3.setNome("BMW");
	fabricanteServico.incluir(fabricante3); 	
	
	Documento documento3 = new Documento();
	documento2.setName("ABC789"); 
	documentoServico.incluir(documento3);	    
    	
    
	Chave chave3 = new Chave();
	chave3.setNome("ZUR458");
	chaveServico.incluir(chave3);   	
	
	Carro carro3 = new Carro();
	carro3.setNome("Kombi");
	carro3.setChave(chave3);
	carro3.setDocumento(documento3);
	carro3.setFabricante(fabricante3);
	carroServico.inserir(carro3);
 	
	
	}	
	
}
