package br.com.senac.servico;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senac.dominio.Carro;
import br.com.senac.dominio.Livro;
import br.com.senac.repositorio.CarroRepositorio;
import javassist.tools.rmi.ObjectNotFoundException;

@Service
public class CarroServico {
	
	@Autowired
	private CarroRepositorio repoCarro;
	
	public Carro inserir (Carro carro) {
		carro.setId(null);
		return repoCarro.save(carro);
	}
	
	public void Excluir(Integer id) {
		repoCarro.findById(id);
	}

	
	private Carro listar(Integer id) throws javassist.tools.rmi.ObjectNotFoundException {
		Optional<Carro> objCarro = repoCarro.findById(id);
		return objCarro.orElseThrow(() -> new ObjectNotFoundException
				("Carro não encontrado ! id= " + id + ", Tipo: " + Carro.class.getName()));
		
	}
	
	public Carro alterar(Carro objCarro) throws javassist.tools.rmi.ObjectNotFoundException{
		Carro objCarroEncontrado = listar(objCarro.getId()); 
		objCarroEncontrado.setNome(objCarro.getNome());
		
		return repoCarro.save(objCarroEncontrado);
		
	}
	
}

