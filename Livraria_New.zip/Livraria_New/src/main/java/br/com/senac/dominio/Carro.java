package br.com.senac.dominio;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Carro {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private String nome;

	public List<Acessorio> getAcessorio() {
		return acessorio;
	}

	public void setAcessorio(List<Acessorio> acessorio) {
		this.acessorio = acessorio;
	}

	@OneToOne
	@JoinColumn (name = "chave_id") 
	private Chave chave;
	
	
	@OneToOne
	@JoinColumn (name = "documento_id")
	private Documento documento;
	
	@ManyToOne
	@JoinColumn (name = "fabricante_id")
	private Fabricante fabricante;
	
	@ManyToMany
	@JoinTable(name="Carro_Acessorio_id", joinColumns= @JoinColumn(name = "carro_id"), 	inverseJoinColumns = @JoinColumn(name = "acessorio_id"))
	private List<Acessorio> acessorio;
	
		
	
	public Fabricante getFabricante() {
		return fabricante;
	}

	public void setFabricante(Fabricante fabricante) {
		this.fabricante = fabricante;
	}


	public Chave getChave() {
		return chave;
	}

	public void setChave(Chave chave) {
		this.chave = chave;
	}


	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Documento getDocumento() {
		return documento;
	}

	public void setDocumento(Documento documento) {
		this.documento = documento;
	}
	
	

}
