package br.com.senac.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senac.dominio.Chave;
import br.com.senac.dominio.Documento;
import br.com.senac.repositorio.DocumentoRepositorio;
import br.com.senac.servico.exception.ObjectNotFoundException;

@Service
public class DocumentoServico {
	
	@Autowired
	DocumentoRepositorio repoDocumento;

	public Documento incluir(Documento documento) {
		documento.setId(null);
		return repoDocumento.save(documento);
		
	}
	
	public void Excluir(Integer id) {
		repoDocumento.deleteById(id);
	}	
	
	public List<Documento> listaDocumentos(){
		return repoDocumento.findAll();
	}		
	
	public Documento listar (Integer id) throws javassist.tools.rmi.ObjectNotFoundException{
		Optional<Documento> objDocumento = repoDocumento.findById(id);
		return objDocumento.orElseThrow(()-> new ObjectNotFoundException
				("Documento não encontrada! id= "+ id + ", Tipo: " + Documento.class.getName()));
		
	}	


	
}
