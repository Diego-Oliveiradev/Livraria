package br.com.senac.servico;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senac.dominio.Fabricante;
import br.com.senac.repositorio.FabricanteRepositorio;

@Service
public class FabricanteServico {

	@Autowired
	private FabricanteRepositorio repoFabricante;
	
	public Fabricante incluir(Fabricante fabricante) {
		fabricante.setId(null);
		return repoFabricante.save(fabricante);
	}
	
	public List<Fabricante> listaFabricantes(){
		return repoFabricante.findAll();
	}
	
}
