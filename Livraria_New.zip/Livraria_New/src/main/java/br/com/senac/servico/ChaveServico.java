package br.com.senac.servico;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.senac.dominio.Carro;
import br.com.senac.dominio.Chave;
import br.com.senac.dominio.Livro;
import br.com.senac.repositorio.ChaveRepositorio;
import br.com.senac.servico.exception.ObjectNotFoundException;

@Service
public class ChaveServico {

	@Autowired
	private ChaveRepositorio repoChave;
	
	public Chave incluir (Chave chave) {
		chave.setId(null);
		return repoChave.save(chave);
	}
	
	public void Excluir(Integer id) {
		repoChave.deleteById(id);
	}
	
	public List<Chave> listaChaves(){
		return repoChave.findAll();
	}	
	
	public Chave listar (Integer id) throws javassist.tools.rmi.ObjectNotFoundException{
		Optional<Chave> objChave = repoChave.findById(id);
		return objChave.orElseThrow(()-> new ObjectNotFoundException
				("Chave não encontrada! id= "+ id + ", Tipo: " + Chave.class.getName()));
		
	}
	
	public Chave excluir (Chave objChave) throws javassist.tools.rmi.ObjectNotFoundException{
		Chave objChaveEncontrado = listar(objChave.getId());
		objChaveEncontrado.setNome(objChave.getNome());
		
		return repoChave.save(objChave);
		
	}
}




